import { Component } from '@angular/core';

@Component({
  selector: 'app-ofertadep',
  imports: [],
  templateUrl: './ofertadep.component.html',
  styleUrl: './ofertadep.component.css'
})
export class OfertadepComponent {

}
