import { Component } from '@angular/core';

@Component({
  selector: 'app-planes',
  imports: [],
  templateUrl: './planes.component.html',
  styleUrl: './planes.component.css'
})
export class PlanesComponent {

}
