export interface Queja {
  nombre: string;
  correo: string;
  motivo: string;
  fecha: string;
  opciones: string[];
  gravedad: string;
}