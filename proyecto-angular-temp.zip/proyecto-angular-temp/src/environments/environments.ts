export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDbAqh4MnOhM6IaaW0jNv7wmMFDaNjNLwM",
    authDomain: "gymbd-386cc.firebaseapp.com",
    projectId: "gymbd-386cc",
    storageBucket: "gymbd-386cc.firebasestorage.app",
    messagingSenderId: "848674208897",
    appId: "1:848674208897:web:5afdd591b48d11fe6f6180",
    measurementId: "G-80FLQHDYWV"
  }
};
